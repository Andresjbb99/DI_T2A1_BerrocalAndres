package es.ieslosmontecillos.AppAgendaBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppAgendaBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppAgendaBeApplication.class, args);
	}

}
