package es.ieslosmontecillos.AppAgendaBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAgendaBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
